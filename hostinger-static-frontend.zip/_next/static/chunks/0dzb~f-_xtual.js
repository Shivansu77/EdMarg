(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,32341,e=>{"use strict";var t=e.i(43476),r=e.i(71645);let o=(0,r.createContext)(void 0),a="user",i="token",n="edmarg-auth-user-change",s=null,l=null,d=()=>"http://localhost:5000".replace(/\/api\/v1\/?$/,"").replace(/\/$/,""),c=()=>{window.dispatchEvent(new Event(n))},u=()=>{window.localStorage.removeItem(a),window.localStorage.removeItem(i)},p=(e,t)=>{window.localStorage.setItem(a,JSON.stringify(e)),t?window.localStorage.setItem(i,t):window.localStorage.removeItem(i)},f=async e=>{let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{message:t}}},m=e=>{let t=t=>{(t.key===a||t.key===i)&&e()},r=()=>{e()};return window.addEventListener("storage",t),window.addEventListener(n,r),()=>{window.removeEventListener("storage",t),window.removeEventListener(n,r)}},g=()=>{let e=window.localStorage.getItem(a);if(e===s)return l;if(s=e,!e)return l=null,null;try{return l=JSON.parse(e)}catch{return window.localStorage.removeItem(a),s=null,l=null,null}};e.s(["AuthProvider",0,function({children:e}){let a=(0,r.useSyncExternalStore)(m,g,()=>null),n=async(e,t)=>{let r=await fetch(`${d()}/api/v1/users/login`,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:e.trim(),password:t})}),o=await f(r);if(!r.ok)throw Error(o.error||o.message||"Unable to login");if(!o.data?._id||!o.data.email||!o.data.name||!o.data.role)throw u(),c(),Error("Login response was incomplete");let a={_id:o.data._id,name:o.data.name,email:o.data.email,role:o.data.role,profileImage:o.data.profileImage};return p(a,o.data.token),c(),a},s=async()=>{try{let e=window.localStorage.getItem(i),t=await fetch(`${d()}/api/v1/users/logout`,{method:"POST",credentials:"include",headers:e?{Authorization:`Bearer ${e}`}:void 0});if(!t.ok){let e=await f(t);throw Error(e.error||e.message||"Unable to logout")}}finally{u(),c()}};return(0,t.jsx)(o.Provider,{value:{user:a,isLoading:!1,login:n,logout:s,updateUser:e=>{let t=g();t&&(p({...t,...e},window.localStorage.getItem(i)||void 0),c())}},children:e})},"useAuth",0,function(){let e=(0,r.useContext)(o);if(!e)throw Error("useAuth must be used within AuthProvider");return e}])},33525,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"warnOnce",{enumerable:!0,get:function(){return o}});let o=e=>{}},18967,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={DecodeError:function(){return y},MiddlewareNotFoundError:function(){return x},MissingStaticPage:function(){return w},NormalizeError:function(){return b},PageNotFoundError:function(){return v},SP:function(){return g},ST:function(){return h},WEB_VITALS:function(){return i},execOnce:function(){return n},getDisplayName:function(){return u},getLocationOrigin:function(){return d},getURL:function(){return c},isAbsoluteUrl:function(){return l},isResSent:function(){return p},loadGetInitialProps:function(){return m},normalizeRepeatedSlashes:function(){return f},stringifyError:function(){return E}};for(var a in o)Object.defineProperty(r,a,{enumerable:!0,get:o[a]});let i=["CLS","FCP","FID","INP","LCP","TTFB"];function n(e){let t,r=!1;return(...o)=>(r||(r=!0,t=e(...o)),t)}let s=/^[a-zA-Z][a-zA-Z\d+\-.]*?:/,l=e=>s.test(e);function d(){let{protocol:e,hostname:t,port:r}=window.location;return`${e}//${t}${r?":"+r:""}`}function c(){let{href:e}=window.location,t=d();return e.substring(t.length)}function u(e){return"string"==typeof e?e:e.displayName||e.name||"Unknown"}function p(e){return e.finished||e.headersSent}function f(e){let t=e.split("?");return t[0].replace(/\\/g,"/").replace(/\/\/+/g,"/")+(t[1]?`?${t.slice(1).join("?")}`:"")}async function m(e,t){let r=t.res||t.ctx&&t.ctx.res;if(!e.getInitialProps)return t.ctx&&t.Component?{pageProps:await m(t.Component,t.ctx)}:{};let o=await e.getInitialProps(t);if(r&&p(r))return o;if(!o)throw Object.defineProperty(Error(`"${u(e)}.getInitialProps()" should resolve to an object. But found "${o}" instead.`),"__NEXT_ERROR_CODE",{value:"E1025",enumerable:!1,configurable:!0});return o}let g="u">typeof performance,h=g&&["mark","measure","getEntriesByName"].every(e=>"function"==typeof performance[e]);class y extends Error{}class b extends Error{}class v extends Error{constructor(e){super(),this.code="ENOENT",this.name="PageNotFoundError",this.message=`Cannot find module for page: ${e}`}}class w extends Error{constructor(e,t){super(),this.message=`Failed to load static file for page: ${e} ${t}`}}class x extends Error{constructor(){super(),this.code="ENOENT",this.message="Cannot find the middleware module"}}function E(e){return JSON.stringify({message:e.message,stack:e.stack})}},98183,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={assign:function(){return l},searchParamsToUrlQuery:function(){return i},urlQueryToSearchParams:function(){return s}};for(var a in o)Object.defineProperty(r,a,{enumerable:!0,get:o[a]});function i(e){let t={};for(let[r,o]of e.entries()){let e=t[r];void 0===e?t[r]=o:Array.isArray(e)?e.push(o):t[r]=[e,o]}return t}function n(e){return"string"==typeof e?e:("number"!=typeof e||isNaN(e))&&"boolean"!=typeof e?"":String(e)}function s(e){let t=new URLSearchParams;for(let[r,o]of Object.entries(e))if(Array.isArray(o))for(let e of o)t.append(r,n(e));else t.set(r,n(o));return t}function l(e,...t){for(let r of t){for(let t of r.keys())e.delete(t);for(let[t,o]of r.entries())e.append(t,o)}return e}},75254,e=>{"use strict";var t=e.i(71645);let r=(...e)=>e.filter((e,t,r)=>!!e&&""!==e.trim()&&r.indexOf(e)===t).join(" ").trim(),o=e=>{let t=e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,r)=>r?r.toUpperCase():t.toLowerCase());return t.charAt(0).toUpperCase()+t.slice(1)};var a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let i=(0,t.forwardRef)(({color:e="currentColor",size:o=24,strokeWidth:i=2,absoluteStrokeWidth:n,className:s="",children:l,iconNode:d,...c},u)=>(0,t.createElement)("svg",{ref:u,...a,width:o,height:o,stroke:e,strokeWidth:n?24*Number(i)/Number(o):i,className:r("lucide",s),...!l&&!(e=>{for(let t in e)if(t.startsWith("aria-")||"role"===t||"title"===t)return!0;return!1})(c)&&{"aria-hidden":"true"},...c},[...d.map(([e,r])=>(0,t.createElement)(e,r)),...Array.isArray(l)?l:[l]]));e.s(["default",0,(e,a)=>{let n=(0,t.forwardRef)(({className:n,...s},l)=>(0,t.createElement)(i,{ref:l,iconNode:a,className:r(`lucide-${o(e).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${e}`,n),...s}));return n.displayName=o(e),n}],75254)},5766,e=>{"use strict";let t,r;var o,a=e.i(71645);let i={data:""},n=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,s=/\/\*[^]*?\*\/|  +/g,l=/\n+/g,d=(e,t)=>{let r="",o="",a="";for(let i in e){let n=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+n+";":o+="f"==i[1]?d(n,i):i+"{"+d(n,"k"==i[1]?"":t)+"}":"object"==typeof n?o+=d(n,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=n&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=d.p?d.p(i,n):i+":"+n+";")}return r+(t&&a?t+"{"+a+"}":a)+o},c={},u=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+u(e[r]);return t}return e};function p(e){let t,r,o=this||{},a=e.call?e(o.p):e;return((e,t,r,o,a)=>{var i;let p=u(e),f=c[p]||(c[p]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(p));if(!c[f]){let t=p!==e?e:(e=>{let t,r,o=[{}];for(;t=n.exec(e.replace(s,""));)t[4]?o.shift():t[3]?(r=t[3].replace(l," ").trim(),o.unshift(o[0][r]=o[0][r]||{})):o[0][t[1]]=t[2].replace(l," ").trim();return o[0]})(e);c[f]=d(a?{["@keyframes "+f]:t}:t,r?"":"."+f)}let m=r&&c.g?c.g:null;return r&&(c.g=c[f]),i=c[f],m?t.data=t.data.replace(m,i):-1===t.data.indexOf(i)&&(t.data=o?i+t.data:t.data+i),f})(a.unshift?a.raw?(t=[].slice.call(arguments,1),r=o.p,a.reduce((e,o,a)=>{let i=t[a];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+o+(null==i?"":i)},"")):a.reduce((e,t)=>Object.assign(e,t&&t.call?t(o.p):t),{}):a,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i})(o.target),o.g,o.o,o.k)}p.bind({g:1});let f,m,g,h=p.bind({k:1});function y(e,t){let r=this||{};return function(){let o=arguments;function a(i,n){let s=Object.assign({},i),l=s.className||a.className;r.p=Object.assign({theme:m&&m()},s),r.o=/ *go\d+/.test(l),s.className=p.apply(r,o)+(l?" "+l:""),t&&(s.ref=n);let d=e;return e[0]&&(d=s.as||e,delete s.as),g&&d[0]&&g(s),f(d,s)}return t?t(a):a}}var b=(e,t)=>"function"==typeof e?e(t):e,v=(t=0,()=>(++t).toString()),w=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},x="default",E=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:o}=t;return E(e,{type:+!!e.toasts.find(e=>e.id===o.id),toast:o});case 3:let{toastId:a}=t;return{...e,toasts:e.toasts.map(e=>e.id===a||void 0===a?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},k=[],N={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},j={},P=(e,t=x)=>{j[t]=E(j[t]||N,e),k.forEach(([e,r])=>{e===t&&r(j[t])})},S=e=>Object.keys(j).forEach(t=>P(e,t)),O=(e=x)=>t=>{P(t,e)},C={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},$=e=>(t,r)=>{let o,a=((e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||v()}))(t,e,r);return O(a.toasterId||(o=a.id,Object.keys(j).find(e=>j[e].toasts.some(e=>e.id===o))))({type:2,toast:a}),a.id},A=(e,t)=>$("blank")(e,t);A.error=$("error"),A.success=$("success"),A.loading=$("loading"),A.custom=$("custom"),A.dismiss=(e,t)=>{let r={type:3,toastId:e};t?O(t)(r):S(r)},A.dismissAll=e=>A.dismiss(void 0,e),A.remove=(e,t)=>{let r={type:4,toastId:e};t?O(t)(r):S(r)},A.removeAll=e=>A.remove(void 0,e),A.promise=(e,t,r)=>{let o=A.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?b(t.success,e):void 0;return a?A.success(a,{id:o,...r,...null==r?void 0:r.success}):A.dismiss(o),e}).catch(e=>{let a=t.error?b(t.error,e):void 0;a?A.error(a,{id:o,...r,...null==r?void 0:r.error}):A.dismiss(o)}),e};var I=1e3,L=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,T=h`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,_=h`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,M=y("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${L} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${T} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${_} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,z=h`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,D=y("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${z} 1s linear infinite;
`,R=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,U=h`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,F=y("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${R} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${U} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,B=y("div")`
  position: absolute;
`,H=y("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,J=h`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,W=y("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${J} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Z=({toast:e})=>{let{icon:t,type:r,iconTheme:o}=e;return void 0!==t?"string"==typeof t?a.createElement(W,null,t):t:"blank"===r?null:a.createElement(H,null,a.createElement(D,{...o}),"loading"!==r&&a.createElement(B,null,"error"===r?a.createElement(M,{...o}):a.createElement(F,{...o})))},q=y("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,K=y("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Q=a.memo(({toast:e,position:t,style:r,children:o})=>{let i=e.height?((e,t)=>{let r=e.includes("top")?1:-1,[o,a]=w()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*r}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*r}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${h(o)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${h(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},n=a.createElement(Z,{toast:e}),s=a.createElement(K,{...e.ariaProps},b(e.message,e));return a.createElement(q,{className:e.className,style:{...i,...r,...e.style}},"function"==typeof o?o({icon:n,message:s}):a.createElement(a.Fragment,null,n,s))});o=a.createElement,d.p=void 0,f=o,m=void 0,g=void 0;var G=({id:e,className:t,style:r,onHeightUpdate:o,children:i})=>{let n=a.useCallback(t=>{if(t){let r=()=>{o(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,o]);return a.createElement("div",{ref:n,className:t,style:r},i)},V=p`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;e.s(["Toaster",0,({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:o,children:i,toasterId:n,containerStyle:s,containerClassName:l})=>{let{toasts:d,handlers:c}=((e,t="default")=>{let{toasts:r,pausedAt:o}=((e={},t=x)=>{let[r,o]=(0,a.useState)(j[t]||N),i=(0,a.useRef)(j[t]);(0,a.useEffect)(()=>(i.current!==j[t]&&o(j[t]),k.push([t,o]),()=>{let e=k.findIndex(([e])=>e===t);e>-1&&k.splice(e,1)}),[t]);let n=r.toasts.map(t=>{var r,o,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(o=e[t.type])?void 0:o.duration)||(null==e?void 0:e.duration)||C[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...r,toasts:n}})(e,t),i=(0,a.useRef)(new Map).current,n=(0,a.useCallback)((e,t=I)=>{if(i.has(e))return;let r=setTimeout(()=>{i.delete(e),s({type:4,toastId:e})},t);i.set(e,r)},[]);(0,a.useEffect)(()=>{if(o)return;let e=Date.now(),a=r.map(r=>{if(r.duration===1/0)return;let o=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(o<0){r.visible&&A.dismiss(r.id);return}return setTimeout(()=>A.dismiss(r.id,t),o)});return()=>{a.forEach(e=>e&&clearTimeout(e))}},[r,o,t]);let s=(0,a.useCallback)(O(t),[t]),l=(0,a.useCallback)(()=>{s({type:5,time:Date.now()})},[s]),d=(0,a.useCallback)((e,t)=>{s({type:1,toast:{id:e,height:t}})},[s]),c=(0,a.useCallback)(()=>{o&&s({type:6,time:Date.now()})},[o,s]),u=(0,a.useCallback)((e,t)=>{let{reverseOrder:o=!1,gutter:a=8,defaultPosition:i}=t||{},n=r.filter(t=>(t.position||i)===(e.position||i)&&t.height),s=n.findIndex(t=>t.id===e.id),l=n.filter((e,t)=>t<s&&e.visible).length;return n.filter(e=>e.visible).slice(...o?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+a,0)},[r]);return(0,a.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)n(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[r,n]),{toasts:r,handlers:{updateHeight:d,startPause:l,endPause:c,calculateOffset:u}}})(r,n);return a.createElement("div",{"data-rht-toaster":n||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...s},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(r=>{let n,s,l=r.position||t,d=c.calculateOffset(r,{reverseOrder:e,gutter:o,defaultPosition:t}),u=(n=l.includes("top"),s=l.includes("center")?{justifyContent:"center"}:l.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:w()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${d*(n?1:-1)}px)`,...n?{top:0}:{bottom:0},...s});return a.createElement(G,{id:r.id,key:r.id,onHeightUpdate:c.updateHeight,className:r.visible?V:"",style:u},"custom"===r.type?b(r.message,r):i?i(r):a.createElement(Q,{toast:r,position:l}))}))},"default",0,A],5766)},31900,e=>{"use strict";var t=e.i(43476),r=e.i(32341),o=e.i(71645);let a=(0,o.createContext)(void 0),i=({children:e})=>{let[r,i]=(0,o.useState)(!1),[n,s]=(0,o.useState)(!0);return(0,t.jsx)(a.Provider,{value:{isDark:r,toggleTheme:()=>{i(!r)},sidebarOpen:n,toggleSidebar:()=>{s(!n)}},children:e})};var n=e.i(5766);e.s(["Providers",0,({children:e})=>(0,t.jsx)(r.AuthProvider,{children:(0,t.jsxs)(i,{children:[e,(0,t.jsx)(n.Toaster,{position:"bottom-right",toastOptions:{style:{background:"#fff",color:"#363636",boxShadow:"0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",borderRadius:"0.75rem"}}})]})})],31900)},33562,e=>{"use strict";var t=e.i(43476),r=e.i(71645),o=e.i(75254);let a=(0,o.default)("wifi-off",[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}],["path",{d:"M5 12.859a10 10 0 0 1 5.17-2.69",key:"1dl1wf"}],["path",{d:"M19 12.859a10 10 0 0 0-2.007-1.523",key:"4k23kn"}],["path",{d:"M2 8.82a15 15 0 0 1 4.177-2.643",key:"1grhjp"}],["path",{d:"M22 8.82a15 15 0 0 0-11.288-3.764",key:"z3jwby"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]]),i=(0,o.default)("refresh-ccw",[["path",{d:"M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"14sxne"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",key:"1hlbsb"}],["path",{d:"M16 16h5v5",key:"ccwih5"}]]);e.s(["NetworkStatus",0,function(){let[e,o]=(0,r.useState)(!1);return((0,r.useEffect)(()=>{{o(!navigator.onLine);let e=()=>o(!1),t=()=>o(!0);return window.addEventListener("online",e),window.addEventListener("offline",t),()=>{window.removeEventListener("online",e),window.removeEventListener("offline",t)}}},[]),e)?(0,t.jsx)("div",{className:"fixed inset-0 z-[9999] flex items-center justify-center bg-white/90 backdrop-blur-sm px-4",children:(0,t.jsxs)("div",{className:"text-center p-8 bg-white rounded-2xl shadow-xl border border-gray-100 max-w-md w-full",children:[(0,t.jsx)("div",{className:"flex justify-center mb-6",children:(0,t.jsx)("div",{className:"bg-red-50 p-4 rounded-full",children:(0,t.jsx)(a,{className:"w-12 h-12 text-red-500"})})}),(0,t.jsx)("h2",{className:"text-2xl font-bold text-gray-900 mb-3",children:"No Internet Connection"}),(0,t.jsx)("p",{className:"text-gray-600 mb-8",children:"It looks like you've lost your network connection. Please check your Wi-Fi or mobile data and try again."}),(0,t.jsxs)("button",{onClick:()=>window.location.reload(),className:"inline-flex items-center justify-center gap-2 w-full px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors",children:[(0,t.jsx)(i,{className:"w-5 h-5"}),"Try to Reconnect"]})]})}):null}],33562)}]);